
OneRing_Config = {
	["ProfileStorage"] = {
		["default"] = {
			["XTZoomTime"] = 0,
			["ShowKeys"] = false,
			["Bindings"] = {
				["PICKLOCKDE"] = "[nocombat]V",
				["RaidMarkers"] = "SHIFT-BUTTON5",
				["Compainons"] = "[noflying,nocombat]BUTTON4",
				["Travel"] = "[noflying,nocombat]CTRL-BUTTON5",
				["Buffs"] = "[noflying,nocombat]BUTTON5",
			},
			["XTScaleSpeed"] = -1.199999928474426,
			["ClickPriority"] = false,
			["RingAtMouse"] = true,
			["ShowCenterCaption"] = true,
			["UseGameTooltip"] = false,
			["RingOptions"] = {
				["Travel#ClickActivation"] = true,
			},
			["XTPointerSpeed"] = 4,
			["MouseBucket"] = 1,
		},
	},
	["PersistentStorage"] = {
		["RingKeeper"] = {
			["Books"] = {
				{
					["c"] = "bca8d2",
					["id"] = 750750,
					["rtype"] = "companion",
					["fastClick"] = true,
					["fcSlice"] = true,
				}, -- [1]
				{
					["c"] = "48b4d2",
					["id"] = 93198,
					["rtype"] = "companion",
					["fastClick"] = true,
					["fcSlice"] = true,
				}, -- [2]
				{
					["c"] = "7e46d2",
					["id"] = 979042,
					["rtype"] = "companion",
				}, -- [3]
				{
					["c"] = "d2ab4c",
					["id"] = 84287,
					["rtype"] = "companion",
				}, -- [4]
				{
					["c"] = "d26d2f",
					["id"] = 9931566,
					["rtype"] = "companion",
				}, -- [5]
				["save"] = true,
				["name"] = "Books",
				["author"] = "162-Area 52 - Free-Pick-Shoufz",
			},
			["Outlands"] = {
				{
					["id"] = 777016,
					["c"] = "d7ba58",
					["caption"] = "Shattrath",
				}, -- [1]
				{
					["c"] = "2b7635",
					["id"] = 777017,
					["caption"] = "Area 52",
				}, -- [2]
				["save"] = true,
				["name"] = "Outlands",
				["author"] = "Shouf",
			},
			["PICKLOCKDE"] = {
				{
					["c"] = "00e5ff",
					["id"] = 1804,
					["fastClick"] = true,
					["fcSlice"] = true,
				}, -- [1]
				{
					["c"] = "00e5ff",
					["id"] = 13262,
					["fastClick"] = true,
					["fcSlice"] = true,
				}, -- [2]
				["offset"] = 90,
				["name"] = "PICKLOCK/DE",
				["author"] = "Shouf",
				["hotkey"] = "[nocombat]V",
				["save"] = true,
			},
			["OPieFastClick"] = {
				["Books"] = 2,
				["PICKLOCKDE"] = 2,
				["HS"] = 1,
				["Compainons"] = 7,
				["Banking"] = 4,
			},
			["Banking"] = {
				{
					["id"] = 1180097,
					["rtype"] = "item",
					["c"] = "56c6cf",
					["onlyWhilePresent"] = true,
					["byName"] = true,
				}, -- [1]
				{
					["id"] = 110000,
					["rtype"] = "item",
					["c"] = "d2c989",
					["onlyWhilePresent"] = true,
					["byName"] = true,
				}, -- [2]
				{
					["id"] = 1903512,
					["rtype"] = "item",
					["c"] = "a8a698",
					["onlyWhilePresent"] = true,
					["byName"] = true,
				}, -- [3]
				{
					["c"] = "89bfd3",
					["id"] = 93417,
					["rtype"] = "companion",
					["fastClick"] = true,
					["fcSlice"] = true,
				}, -- [4]
				{
					["c"] = "89bfd3",
					["id"] = 985356,
					["rtype"] = "companion",
				}, -- [5]
				["save"] = true,
				["name"] = "Banking",
				["author"] = "162-Area 52 - Free-Pick-Shoufz",
			},
			["OPieDeletedRings"] = {
				["DruidUtility"] = true,
				["DruidShift"] = true,
				["WarlockDemons"] = true,
				["DKCombat"] = true,
				["CommonTrades"] = true,
				["MageTravel"] = true,
				["WarlockStones"] = true,
				["HunterTraps"] = true,
				["MageShields"] = true,
				["DeathKnightPresence"] = true,
				["ShamanWeapons"] = true,
				["HunterAspects"] = true,
				["WarriorStances"] = true,
				["MageArmor"] = true,
				["PaladinAuras"] = true,
			},
			["RaidMarkers"] = {
				{
					["c"] = "000000",
					["id"] = 499587,
				}, -- [1]
				{
					["c"] = "f8fdfe",
					["id"] = 499590,
				}, -- [2]
				{
					["c"] = "fe4845",
					["id"] = 499593,
				}, -- [3]
				{
					["c"] = "3186fe",
					["id"] = 499595,
				}, -- [4]
				{
					["c"] = "7cc1fe",
					["id"] = 499591,
				}, -- [5]
				{
					["c"] = "50fe45",
					["id"] = 499588,
				}, -- [6]
				{
					["c"] = "e550fe",
					["id"] = 499592,
				}, -- [7]
				{
					["c"] = "fe703e",
					["id"] = 499594,
				}, -- [8]
				{
					["c"] = "fee453",
					["id"] = 499589,
				}, -- [9]
				["save"] = true,
				["name"] = "RaidMarkers",
				["author"] = "Shouf",
			},
			["HS"] = {
				{
					["c"] = "fd62fc",
					["id"] = 979806,
					["fastClick"] = true,
					["fcSlice"] = true,
					["caption"] = "Rune of Retreat",
				}, -- [1]
				{
					["c"] = "00e5ff",
					["id"] = 80133,
					["caption"] = "Rune of Retreat",
				}, -- [2]
				{
					["id"] = 6948,
					["rtype"] = "item",
					["c"] = "40addf",
				}, -- [3]
				["save"] = true,
				["name"] = "HS",
				["author"] = "Shouf",
			},
			["Travel"] = {
				{
					["c"] = "7fff00",
					["id"] = "HS",
					["rtype"] = "ring",
				}, -- [1]
				{
					["c"] = "7fff00",
					["id"] = "Horde",
					["rtype"] = "ring",
				}, -- [2]
				{
					["c"] = "7fff00",
					["id"] = "EasternKingdoms",
					["rtype"] = "ring",
				}, -- [3]
				{
					["c"] = "7fff00",
					["id"] = "Outlands",
					["rtype"] = "ring",
				}, -- [4]
				{
					["c"] = "7fff00",
					["id"] = "Kalimdor",
					["rtype"] = "ring",
				}, -- [5]
				{
					["c"] = "7fff00",
					["id"] = "Alliance",
					["rtype"] = "ring",
				}, -- [6]
				["author"] = "Shouf",
				["save"] = true,
				["hotkey"] = "CTRL-F5",
				["name"] = "Travel",
			},
			["Alliance"] = {
				{
					["id"] = 777003,
					["c"] = "00e5ff",
					["caption"] = "Stormwind",
				}, -- [1]
				{
					["c"] = "fe70fe",
					["id"] = 777015,
					["caption"] = "Exodar",
				}, -- [2]
				{
					["c"] = "fe9f42",
					["id"] = 777005,
					["caption"] = "Ironforge",
				}, -- [3]
				{
					["c"] = "c22dfe",
					["id"] = 777004,
					["caption"] = "Darnassus",
				}, -- [4]
				{
					["c"] = "fe8c6f",
					["id"] = 1777072,
					["caption"] = "Morgan's Vigil",
				}, -- [5]
				{
					["c"] = "0e5c1c",
					["caption"] = "Auberdine",
					["id"] = 1777059,
				}, -- [6]
				{
					["c"] = "006f7c",
					["caption"] = "Southshore",
					["id"] = 1777081,
				}, -- [7]
				{
					["c"] = "70fea9",
					["caption"] = "Theramore Isle",
					["id"] = 1777048,
				}, -- [8]
				["author"] = "Shouf",
				["name"] = "Alliance",
				["save"] = true,
			},
			["Kalimdor"] = {
				{
					["id"] = 777010,
					["c"] = "91d76f",
					["caption"] = "Ratchet",
				}, -- [1]
				{
					["id"] = 777009,
					["c"] = "9e8937",
					["caption"] = "Tanaris",
				}, -- [2]
				{
					["id"] = 777013,
					["c"] = "fede68",
					["caption"] = "Silithus",
				}, -- [3]
				{
					["id"] = 1777024,
					["c"] = "48d740",
					["caption"] = "Camp Mojache",
				}, -- [4]
				{
					["id"] = 83126,
					["c"] = "316c12",
					["caption"] = "Ashenvale",
				}, -- [5]
				{
					["c"] = "fe9560",
					["id"] = 777012,
					["caption"] = "Mudsprocket (Ony)",
				}, -- [6]
				{
					["c"] = "00e5ff",
					["id"] = 777007,
					["caption"] = "Winterspring",
				}, -- [7]
				["save"] = true,
				["name"] = "Kalimdor",
				["author"] = "Shouf",
			},
			["EasternKingdoms"] = {
				{
					["id"] = 777008,
					["c"] = "00e4fe",
					["caption"] = "Booty Bay",
				}, -- [1]
				{
					["id"] = 1777023,
					["c"] = "fe785e",
					["caption"] = "Yojamba Isle",
				}, -- [2]
				{
					["c"] = "fe221f",
					["id"] = 777020,
					["caption"] = "Gurubashi Arena",
				}, -- [3]
				{
					["id"] = 777006,
					["c"] = "fef289",
					["caption"] = "Lights Hope",
				}, -- [4]
				{
					["id"] = 83128,
					["c"] = "0e8f17",
					["caption"] = "Hilsbrad Foothills",
				}, -- [5]
				{
					["c"] = "31a480",
					["id"] = 777011,
					["caption"] = "Thorium Point",
				}, -- [6]
				["author"] = "Shouf",
				["name"] = "Eastern Kingdoms",
				["save"] = true,
			},
			["Horde"] = {
				{
					["id"] = 777002,
					["c"] = "39fe4b",
					["caption"] = "Thunder Bluff",
				}, -- [1]
				{
					["id"] = 777000,
					["c"] = "fe672e",
					["caption"] = "Orgrimmar",
				}, -- [2]
				{
					["c"] = "1e7a22",
					["id"] = 777001,
					["caption"] = "Undercity",
				}, -- [3]
				{
					["id"] = 1777043,
					["c"] = "feca27",
					["caption"] = "Desolace",
				}, -- [4]
				{
					["c"] = "fdfee6",
					["id"] = 777014,
					["caption"] = "Silvermoon City",
				}, -- [5]
				{
					["c"] = "376d25",
					["caption"] = "Tarren MIll",
					["id"] = 1777082,
				}, -- [6]
				["author"] = "Shouf",
				["name"] = "Horde",
				["save"] = true,
			},
			["Buffs"] = {
				{
					["c"] = "5afe7c",
					["id"] = 10399,
				}, -- [1]
				{
					["c"] = "00e5ff",
					["id"] = 23028,
				}, -- [2]
				{
					["c"] = "2774fe",
					["id"] = 10432,
					["fastClick"] = true,
					["fcSlice"] = true,
				}, -- [3]
				{
					["c"] = "fe6abc",
					["id"] = 21850,
				}, -- [4]
				{
					["c"] = "8c19fe",
					["id"] = 978703,
				}, -- [5]
				{
					["c"] = "fed043",
					["id"] = 25898,
				}, -- [6]
				{
					["c"] = "00e5ff",
					["id"] = 20166,
				}, -- [7]
				{
					["c"] = "fafefa",
					["id"] = 21564,
				}, -- [8]
				{
					["c"] = "008f9b",
					["id"] = 546,
				}, -- [9]
				{
					["c"] = "fe6458",
					["id"] = 25289,
				}, -- [10]
				{
					["c"] = "f7fefd",
					["id"] = 13159,
				}, -- [11]
				{
					["c"] = "fe9bc0",
					["id"] = 13161,
				}, -- [12]
				{
					["c"] = "74cafe",
					["id"] = 16356,
				}, -- [13]
				{
					["c"] = "fe7542",
					["id"] = 16342,
				}, -- [14]
				{
					["c"] = "fe8031",
					["id"] = 30482,
				}, -- [15]
				{
					["c"] = "48fe48",
					["id"] = 28176,
				}, -- [16]
				{
					["c"] = "00e5ff",
					["id"] = 32999,
				}, -- [17]
				["author"] = "Shouf",
				["name"] = "Buffs",
				["save"] = true,
			},
			["Compainons"] = {
				{
					["c"] = "76fe78",
					["onlyWhilePresent"] = true,
					["id"] = "Banking",
					["rtype"] = "ring",
				}, -- [1]
				{
					["c"] = "fef2a5",
					["onlyWhilePresent"] = true,
					["id"] = "Books",
					["rtype"] = "ring",
				}, -- [2]
				{
					["c"] = "68d258",
					["id"] = 979850,
					["rtype"] = "companion",
				}, -- [3]
				{
					["c"] = "d2404a",
					["id"] = 999317,
					["rtype"] = "companion",
				}, -- [4]
				{
					["c"] = "3aa7d2",
					["id"] = 83050,
					["rtype"] = "companion",
				}, -- [5]
				{
					["c"] = "89bfd3",
					["id"] = 92981,
					["rtype"] = "companion",
				}, -- [6]
				{
					["c"] = "2bd21f",
					["id"] = 9930889,
					["rtype"] = "companion",
					["fastClick"] = true,
					["fcSlice"] = true,
				}, -- [7]
				{
					["id"] = 1903513,
					["rtype"] = "item",
					["c"] = "a023df",
					["onlyWhilePresent"] = true,
					["byName"] = true,
				}, -- [8]
				{
					["byName"] = true,
					["c"] = "dfcc9d",
					["id"] = 10,
					["rtype"] = "item",
					["onlyWhilePresent"] = true,
				}, -- [9]
				["name"] = "Compainons",
				["author"] = "Shouf",
				["hotkey"] = "SHIFT-I",
				["save"] = true,
			},
		},
	},
	["CharProfiles"] = {
	},
}
OPie_Locale = nil
