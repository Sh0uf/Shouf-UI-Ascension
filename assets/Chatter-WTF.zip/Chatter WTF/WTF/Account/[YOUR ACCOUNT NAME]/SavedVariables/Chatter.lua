
ChatterDB = {
	["namespaces"] = {
		["PlayerNames"] = {
			["profiles"] = {
				["Default"] = {
					["excludeMaxLevel"] = false,
					["nameColoring"] = "NONE",
					["saveGroup"] = true,
					["levelByDiff"] = false,
					["saveFriends"] = true,
					["emphasizeSelfInText"] = false,
					["includeLevel"] = true,
				},
			},
			["realm"] = {},
		},
		["AltLinks"] = {
			["profiles"] = {
				["Default"] = {
					["color"] = {
						nil, -- [1]
						0.3803921568627451, -- [2]
						0.5411764705882353, -- [3]
					},
				},
			},
		},
		["Scrollback"] = {
			["profiles"] = {
				["Default"] = {
					["FRAME_1"] = 1000,
				},
				["ShoufUI"] = {
					["FRAME_1"] = 1000,
				},
			},
		},
		["Invite Links"] = {
			["profiles"] = {
				["Default"] = {
					["altClickToinvite"] = true,
					["words"] = {
						["inv"] = "inv",
						["invite"] = "invite",
					},
				},
				["ShoufUI"] = {
					["altClickToinvite"] = true,
					["words"] = {
						["inv"] = "inv",
						["invite"] = "invite",
					},
				},
			},
		},
		["ChannelColors"] = {
			["profiles"] = {
				["Default"] = {
					["colors"] = {
						["RealID Conversation"] = {
							["r"] = 0,
							["g"] = 0.6941176881082356,
							["b"] = 0.9411765262484551,
						},
						["General"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.752941220998764,
							["b"] = 0.752941220998764,
						},
						["Raid Leader"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.2823529578745365,
							["b"] = 0.03529411973431706,
						},
						["LookingForGroup"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.752941220998764,
							["b"] = 0.752941220998764,
						},
						["Party"] = {
							["r"] = 0.6666667060926557,
							["g"] = 0.6666667060926557,
							["b"] = 1.000000059138984,
						},
						["Whisper"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.501960813999176,
							["b"] = 1.000000059138984,
						},
						["Raid"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.4980392451398075,
							["b"] = 0,
						},
						["Battleground Leader"] = {
							["r"] = 1,
							["g"] = 0.282352941176,
							["b"] = 0.035294117647,
						},
						["Raid Warning"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.2823529578745365,
							["b"] = 0,
						},
						["Party Leader"] = {
							["r"] = 0.4627451254054904,
							["g"] = 0.7843137718737125,
							["b"] = 1.000000059138984,
						},
						["Officer"] = {
							["r"] = 0.250980406999588,
							["g"] = 0.752941220998764,
							["b"] = 0.250980406999588,
						},
						["World"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.752941220998764,
							["b"] = 0.752941220998764,
						},
						["Newcomers"] = {
							["r"] = 0,
							["g"] = 1.000000059138984,
							["b"] = 0.8196078916080296,
						},
						["Yell"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.250980406999588,
							["b"] = 0.250980406999588,
						},
						["LocalDefense"] = {
							["r"] = 0.439215712249279,
							["g"] = 0.3294117841869593,
							["b"] = 0.3294117841869593,
						},
						["RealID Whisper"] = {
							["r"] = 0,
							["g"] = 1.000000059138984,
							["b"] = 0.9647059394046664,
						},
						["Guild"] = {
							["r"] = 0.250980406999588,
							["g"] = 1.000000059138984,
							["b"] = 0.250980406999588,
						},
						["Trade"] = {
							["r"] = 0.9098039753735066,
							["g"] = 0.6196078797802329,
							["b"] = 0.4745098319835961,
						},
						["Say"] = {
							["r"] = 1.000000059138984,
							["g"] = 1.000000059138984,
							["b"] = 1.000000059138984,
						},
						["Ascension"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.9529412328265607,
							["b"] = 0.6509804306551814,
						},
						["world"] = {
							["r"] = 0.6313725863583386,
							["g"] = 0.6000000354833901,
							["b"] = 0.4117647302336991,
						},
						["Battleground"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.4980392451398075,
							["b"] = 0,
						},
					},
				},
			},
		},
		["StickyChannels"] = {
			["profiles"] = {
				["Default"] = {
					["BN_WHISPER"] = false,
				},
			},
		},
		["RealIdPolish"] = {
		},
		["ChatFrameBorders"] = {
			["profiles"] = {
				["Default"] = {
					["frames"] = {
						["FRAME_1"] = {
							["edgeSize"] = 1,
							["tileSize"] = 1,
							["borderColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
							["border"] = "None",
							["background"] = "None",
							["backgroundColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
							["inset"] = 1,
						},
						["FRAME_9"] = {
							["border"] = "None",
							["background"] = "None",
							["backgroundColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
							["borderColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
						},
						["FRAME_6"] = {
							["border"] = "None",
							["background"] = "None",
							["backgroundColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
							["borderColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
						},
						["FRAME_5"] = {
							["border"] = "None",
							["background"] = "None",
							["backgroundColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
							["borderColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
						},
						["FRAME_8"] = {
							["border"] = "None",
							["background"] = "None",
							["backgroundColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
							["borderColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
						},
						["FRAME_7"] = {
							["border"] = "None",
							["background"] = "None",
							["backgroundColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
							["borderColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
						},
						["FRAME_3"] = {
							["border"] = "None",
							["background"] = "None",
							["backgroundColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
							["borderColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
						},
						["FRAME_4"] = {
							["border"] = "None",
							["background"] = "None",
							["backgroundColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
							["borderColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
						},
						["FRAME_10"] = {
							["border"] = "None",
							["background"] = "None",
							["backgroundColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
							["borderColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
						},
						["FRAME_2"] = {
							["border"] = "None",
							["background"] = "None",
							["backgroundColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
							["borderColor"] = {
								["a"] = 0,
								["r"] = 0.06666666666666667,
								["g"] = 0.09019607843137255,
								["b"] = 0.1176470588235294,
							},
						},
					},
				},
			},
		},
		["Buttons"] = {
			["profiles"] = {
				["Default"] = {
					["scrollReminder"] = false,
				},
			},
		},
		["Server Positioning"] = {
			["profiles"] = {
				["Default"] = {
					["windowdata"] = {
						{
							["point"] = "BOTTOMLEFT",
							["xOffset"] = 0.003987629432381993,
							["width"] = 401.5042533785519,
							["height"] = 122.5299224604963,
							["yOffset"] = 0.02838541734578992,
						}, -- [1]
						nil, -- [2]
						{
							["point"] = "BOTTOMLEFT",
							["xOffset"] = 0.003987629432381993,
							["width"] = 401.5042533785519,
							["height"] = 122.5299224604963,
							["yOffset"] = 0.02838541734578992,
						}, -- [3]
						{
							["point"] = "BOTTOMLEFT",
							["xOffset"] = 0.003987629432381993,
							["width"] = 401.5042533785519,
							["height"] = 122.5299224604963,
							["yOffset"] = 0.02838541734578992,
						}, -- [4]
						{
							["point"] = "BOTTOMLEFT",
							["height"] = 122.5299224604963,
							["width"] = 401.5042533785519,
							["xOffset"] = 0.003987629432381993,
							["yOffset"] = 0.02838541734578992,
						}, -- [5]
						{
							["point"] = "BOTTOMLEFT",
							["height"] = 122.5299224604963,
							["width"] = 401.5042533785519,
							["xOffset"] = 0.003987629432381993,
							["yOffset"] = 0.02838541734578992,
						}, -- [6]
						{
							["point"] = "BOTTOMLEFT",
							["height"] = 122.5299224604963,
							["width"] = 401.5042533785519,
							["xOffset"] = 0.003987629432381993,
							["yOffset"] = 0.02838541734578992,
						}, -- [7]
						{
							["point"] = "BOTTOMLEFT",
							["height"] = 122.5299224604963,
							["width"] = 401.5042533785519,
							["xOffset"] = 0.003987629432381993,
							["yOffset"] = 0.02838541734578992,
						}, -- [8]
						{
							["point"] = "BOTTOMLEFT",
							["height"] = 122.5299224604963,
							["width"] = 401.5042533785519,
							["xOffset"] = 0.003987629432381993,
							["yOffset"] = 0.02838541734578992,
						}, -- [9]
						{
							["point"] = "BOTTOMLEFT",
							["height"] = 122.5299224604963,
							["width"] = 401.5042533785519,
							["xOffset"] = 0.003987629432381993,
							["yOffset"] = 0.02838541734578992,
						}, -- [10]
					},
				},
			},
		},
		["JustifyText"] = {
		},
		["Timestamps"] = {
			["profiles"] = {
				["Default"] = {
					["frames"] = {
						["Frame12"] = true,
						["Frame18"] = true,
						["Frame10"] = true,
						["Frame9"] = true,
						["Frame17"] = true,
						["Frame16"] = true,
						["Frame14"] = true,
						["Frame13"] = true,
						["Frame15"] = true,
						["Frame11"] = true,
						["Frame8"] = true,
					},
					["colorByChannel"] = true,
				},
			},
		},
		["EditBox"] = {
			["profiles"] = {
				["Default"] = {
					["edgeSize"] = 1,
					["border"] = "Square Full White",
					["font"] = "Continuum Medium",
					["tileSize"] = 14,
					["borderColor"] = {
						["b"] = 0.04705882352941176,
						["g"] = 0.03529411764705882,
						["r"] = 0.0196078431372549,
					},
					["height"] = 20,
					["background"] = "ElvUI Blank",
					["inset"] = 1,
					["backgroundColor"] = {
						["a"] = 0.5,
						["b"] = 0.1176470588235294,
						["g"] = 0.09019607843137255,
						["r"] = 0.06666666666666667,
					},
				},
			},
		},
		["Highlight"] = {
		},
		["ChatTabs"] = {
			["profiles"] = {
				["Default"] = {
					["height"] = 26,
					["chattabs"] = false,
				},
			},
		},
		["ChannelNames"] = {
			["profiles"] = {
				["Default"] = {
					["addSpace"] = false,
					["channels"] = {
						["busy BN Whisper To"] = "<Busy>[To]",
						["general"] = "[Gen]",
						["Whisper From"] = "[From]",
						["BN Whisper To"] = "[To]",
						["BN Whisper From"] = "[From]",
						["Whisper To"] = "[To]",
						["ascension"] = "[A]",
						["localdefense"] = "[L]",
						["newcomers"] = "[N]",
						["world"] = "[W]",
					},
				},
			},
		},
		["CopyChat"] = {
		},
		["UrlCopy"] = {
			["profiles"] = {
				["Default"] = {
					["mangleMumble"] = false,
					["mangleTeamspeak"] = false,
				},
			},
		},
		["Editbox History"] = {},
		["ChatFont"] = {
			["profiles"] = {
				["Default"] = {
					["outline"] = "OUTLINE",
					["font"] = "Continuum Medium",
					["fontsize"] = 14,
					["frames"] = {
						["FRAME_1"] = {
							["outline"] = "OUTLINE",
						},
						["FRAME_9"] = {
							["outline"] = "OUTLINE",
						},
						["FRAME_6"] = {
							["outline"] = "OUTLINE",
						},
						["FRAME_5"] = {
							["outline"] = "OUTLINE",
						},
						["FRAME_8"] = {
							["outline"] = "OUTLINE",
						},
						["FRAME_7"] = {
							["outline"] = "OUTLINE",
						},
						["FRAME_3"] = {
							["outline"] = "OUTLINE",
						},
						["FRAME_4"] = {
							["outline"] = "OUTLINE",
						},
						["FRAME_10"] = {
							["outline"] = "OUTLINE",
						},
						["FRAME_2"] = {
							["outline"] = "OUTLINE",
						},
					},
				},
			},
		},
		["Mousewheel Scroll"] = {
		},
	},
	["profileKeys"] = {},
	["profiles"] = {
		["Default"] = {
			["modules"] = {
				["Disable Buttons"] = true,
				["Server Positioning"] = true,
				["Tiny Chat"] = true,
				["BNet"] = false,
				["Borders/Background"] = true,
				["All Edge resizing"] = true,
				["Alt Linking"] = true,
				["ChatTabs"] = true,
				["Editbox History"] = true,
				["Sticky Channels"] = true,
				["Player Class Colors"] = false,
			},
			["welcomeMessaged"] = true,
		},
		["ShoufUI"] = {
			["modules"] = {
				["Tiny Chat"] = true,
				["Sticky Channels"] = true,
				["Server Positioning"] = true,
				["Disable Buttons"] = true,
				["All Edge resizing"] = true,
				["Alt Linking"] = true,
				["BNet"] = false,
				["ChatTabs"] = true,
				["Editbox History"] = true,
				["Borders/Background"] = true,
				["Player Class Colors"] = false,
			},
			["welcomeMessaged"] = false,
		},
	},
}
